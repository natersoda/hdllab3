-------------------------------------------------------------------------------
-- nate ralston
-- lab4 top
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity top is
  port (
    clk_50_mhz   : in  std_logic;
    reset        : in  std_logic;
    pb_add       : in  std_logic;
    pb_sub       : in  std_logic;
    sw_a         : in  std_logic_vector(2 downto 0);
    sw_b         : in  std_logic_vector(2 downto 0);
    hex0_out     : out std_logic_vector(6 downto 0);
    hex1_out     : out std_logic_vector(6 downto 0); 
	hex2_out     : out std_logic_vector(6 downto 0)
  );  
end top;  

architecture arch of top is

component edge_detector is 
  port (
    clk               : in std_logic;
    reset             : in std_logic;
    input             : in std_logic;
    edge              : out std_logic
  );
end component;

component concat is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    sw_in           : in std_logic_vector(2 downto 0);
    concat_out      : out std_logic_vector(3 downto 0)
  );  
end component; 
 
component synchronizer_3bit is 
  port (
    clk               : in std_logic;
    reset             : in std_logic;
    async_in          : in std_logic_vector(2 downto 0);
    sync_out          : out std_logic_vector(2 downto 0)
  );
end component;

 component generic_adder_beh is
  generic (
    bits    : integer := 4
  );
  port (
    a       : in  std_logic_vector(bits-1 downto 0);
    b       : in  std_logic_vector(bits-1 downto 0);
    sel     : in  std_logic;
    sum     : out std_logic_vector(bits-1 downto 0)
  );
end component;

component seven_seg is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    bcd             : in std_logic_vector(3 downto 0);
    seven_seg_out   : out std_logic_vector(6 downto 0)
  );  
end component; 

  signal pb_add_s : std_logic;
  signal pb_sub_s : std_logic;
  signal sel_flag : std_logic;
  signal sw_a_s  : std_logic_vector(2 downto 0);
  signal sw_a_sc : std_logic_vector(3 downto 0);
  signal sw_b_s  : std_logic_vector(2 downto 0);
  signal sw_b_sc : std_logic_vector(3 downto 0);
  signal result : std_logic_vector(3 downto 0);
  signal hex0_bcd_out : std_logic_vector(6 downto 0);
  signal hex1_bcd_out : std_logic_vector(6 downto 0);
  signal hex2_bcd_out : std_logic_vector(6 downto 0);
 
begin

edge_inst_pb_add: edge_detector
    port map(
      reset  => reset,
      clk    => clk_50_mhz,
      input  => pb_add,
	  edge   => pb_add_s
    );

edge_inst_pb_sub: edge_detector
    port map(
      reset  => reset,
      clk    => clk_50_mhz,
      input  => pb_sub,
	  edge   => pb_sub_s
    );

sycnhro_sw_a: synchronizer_3bit
    port map(
      reset      => reset,
      clk        => clk_50_mhz,
      async_in   => sw_a,
	  sync_out   => sw_a_s
    );
	
sycnhro_sw_b: synchronizer_3bit
    port map(
      reset      => reset,
      clk        => clk_50_mhz,
      async_in   => sw_b,
	  sync_out   => sw_b_s
    );

sw_a_concat: concat
    port map(
      reset        => reset,
      clk          => clk_50_mhz,
      sw_in        => sw_a_s,
	  concat_out   => sw_a_sc
    );
	
sw_b_concat: concat
    port map(
      reset        => reset,
      clk          => clk_50_mhz,
      sw_in        => sw_b_s,
	  concat_out   => sw_b_sc
    );
		
math: generic_adder_beh
    port map(
      a          => sw_a_sc,
      b          => sw_b_sc,
      sel        => sel_flag,
      sum        => result
    );	
		
hex0_out_uut: seven_seg
    port map(
      reset          => reset,
      clk            => clk_50_mhz,
      bcd            => sw_a_sc,
	  seven_seg_out  => hex0_bcd_out
    );
		
hex1_out_uut: seven_seg
    port map(
      reset          => reset,
      clk            => clk_50_mhz,
      bcd            => sw_b_sc,
	  seven_seg_out  => hex1_bcd_out
    );
	
hex2_out_uut: seven_seg
    port map(
      reset          => reset,
      clk            => clk_50_mhz,
      bcd            => result,
	  seven_seg_out  => hex2_bcd_out
    );
		
  sel_flag_process : process(clk_50_mhz, reset)
  begin
    if (reset = '1') then
      sel_flag <= '0';
    elsif (clk_50_mhz'event and clk_50_mhz = '1') then
      --decide if sel should be 0 or 1 depending on button
	  if (pb_add_s = '1') then
        sel_flag <= '1';
	  elsif (pb_sub_s = '1') then
        sel_flag <= '0';
      end if;
    end if;
  end process;

  main_adder: process(clk_50_mhz, reset)
  begin
    if (reset = '1') then 
      hex0_out <= "1111111";
      hex1_out <= "1111111";
      hex2_out <= "1111111";
    elsif (clk_50_mhz'event and clk_50_mhz = '1') then
      hex0_out <= hex0_bcd_out;
      hex1_out <= hex1_bcd_out;
      hex2_out <= hex2_bcd_out;
    end if;
  end process; 
end arch;