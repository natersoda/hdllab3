-------------------------------------------------------------------------------
-- nate ralston
-- bcd
-------------------------------------------------------------------------------
library ieee;
use ieee.std_logic_1164.all;      

entity concat is
  port (
    clk             : in std_logic; 
    reset           : in std_logic;
    sw_in           : in std_logic_vector(2 downto 0);
    concat_out      : out std_logic_vector(3 downto 0)
  );  
end concat; 

architecture arch of concat  is

begin
process(clk,reset)
  begin
    if (reset = '1') then 
      concat_out <= "0000";
    elsif (clk'event and clk = '1') then
      concat_out <= '0' & sw_in;
    end if;
  end process;
  
end arch;