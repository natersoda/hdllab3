# Dr. Kaputa
# Quartus II compile script for DE1-SoC  board

# 1] name your project here
set project_name "top"

file delete -force project
file delete -force output_files
file mkdir project
cd project
load_package flow
project_new $project_name
set_global_assignment -name FAMILY Cyclone
set_global_assignment -name DEVICE 5CSEMA5F31C6 
set_global_assignment -name TOP_LEVEL_ENTITY top
set_global_assignment -name PROJECT_OUTPUT_DIRECTORY ../output_files

# 2] include your relative path files here
set_global_assignment -name VHDL_FILE ../../src/top.vhd
set_global_assignment -name VHDL_FILE ../../src/concat.vhd
set_global_assignment -name VHDL_FILE ../../src/synchronizer_3bit.vhd
set_global_assignment -name VHDL_FILE ../../src/seven_seg.vhd
set_global_assignment -name VHDL_FILE ../../src/generic_adder_beh.vhd
set_global_assignment -name VHDL_FILE ../../src/edge_detector.vhd

# 3] set your pin constraints here
#clk
set_location_assignment PIN_AF14 -to clk_50_mhz
#push button ab
set_location_assignment PIN_AA14 -to pb_add
set_location_assignment PIN_AA15 -to pb_sub
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to pb_add
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to pb_sub
# switches for b
set_location_assignment PIN_AB12 -to sw_b[0]
set_location_assignment PIN_AC12 -to sw_b[1]
set_location_assignment PIN_AF9 -to sw_b[2]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_b[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_b[1]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_b[2]
# switches for a
set_location_assignment PIN_AD11 -to sw_a[0]
set_location_assignment PIN_AD12 -to sw_a[1]
set_location_assignment PIN_AE11 -to sw_a[2]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_a[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_a[1]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to sw_a[2]
# reset
set_location_assignment PIN_AE12 -to reset
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to reset
# result hex
set_location_assignment PIN_AE26 -to hex2_out[0]
set_location_assignment PIN_AE27 -to hex2_out[1]
set_location_assignment PIN_AE28 -to hex2_out[2]
set_location_assignment PIN_AG27 -to hex2_out[3]
set_location_assignment PIN_AF28 -to hex2_out[4]
set_location_assignment PIN_AG28 -to hex2_out[5]
set_location_assignment PIN_AH28 -to hex2_out[6]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[1]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[2]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[3]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[4]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[5]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex2_out[6]
#b hex
set_location_assignment PIN_AB23 -to hex1_out[0]
set_location_assignment PIN_AE29 -to hex1_out[1]
set_location_assignment PIN_AD29 -to hex1_out[2]
set_location_assignment PIN_AC28 -to hex1_out[3]
set_location_assignment PIN_AD30 -to hex1_out[4]
set_location_assignment PIN_AC29 -to hex1_out[5]
set_location_assignment PIN_AC30 -to hex1_out[6]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[1]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[2]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[3]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[4]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[5]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex1_out[6]
#a hex
set_location_assignment PIN_AA24 -to hex0_out[0]
set_location_assignment PIN_Y23 -to hex0_out[1]
set_location_assignment PIN_Y24 -to hex0_out[2]
set_location_assignment PIN_W22 -to hex0_out[3]
set_location_assignment PIN_W24 -to hex0_out[4]
set_location_assignment PIN_V23 -to hex0_out[5]
set_location_assignment PIN_W25 -to hex0_out[6]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[0]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[1]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[2]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[3]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[4]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[5]
set_instance_assignment -name IO_STANDARD "3.3-V LVTTL" -to hex0_out[6]

execute_flow -compile
project_close